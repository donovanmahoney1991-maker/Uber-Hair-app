import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert, Platform } from 'react-native';
import RNIap from 'react-native-iap';
import axios from 'axios';

const SKUS = Platform.select({
  ios: ['com.uberhair.membership.yearly'],
  android: ['com.uberhair.membership.yearly']
});

export default function PlatformFeeScreen({ navigation }) {
  const [product, setProduct] = useState(null);

  useEffect(() => {
    async function init() {
      try {
        await RNIap.initConnection();
        const subs = await RNIap.getSubscriptions(SKUS);
        setProduct(subs && subs.length ? subs[0] : null);
      } catch (err) {
        console.warn('IAP init error', err);
      }
    }
    init();
    return () => {
      RNIap.endConnection();
    };
  }, []);

  const onBuy = async () => {
    try {
      const purchase = await RNIap.requestSubscription(SKUS[0]);
      // send receipt to server for verification
      const receipt = purchase.transactionReceipt || purchase.purchaseToken;
      await axios.post('https://base44.com/api/verify-subscription', {
        platform: Platform.OS,
        receipt,
        userId: 'USER_ID_PLACEHOLDER'
      });
      Alert.alert('Success', 'Membership active');
      navigation.replace('Dashboard');
    } catch (err) {
      console.warn(err);
      Alert.alert('Payment failed', err.message || 'Try again');
    }
  };

  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'#FBF8FB'}}>
      <Text style={{fontSize:22,fontWeight:'700',color:'#6F3BB1'}}>Activate UBER HAIR Membership</Text>
      {product ? (
        <>
          <Text style={{margin:20}}>Subscribe: {product.title} — {product.localizedPrice}</Text>
          <Button title="Subscribe $4.99 / year" onPress={onBuy} />
        </>
      ) : <Text>Loading...</Text>}
    </View>
  );
}
