const paypal = require('paypal-rest-sdk');
require('dotenv').config();

paypal.configure({
  'mode': 'live', // live for production; sandbox for testing
  'client_id': process.env.PAYPAL_CLIENT_ID,
  'client_secret': process.env.PAYPAL_CLIENT_SECRET
});

async function createPayPalOrder(body) {
  return new Promise((resolve, reject) => {
    const create_payment_json = {
      "intent": "sale",
      "payer": {
        "payment_method": "paypal"
      },
      "transactions": [{
        "amount": {
          "currency": "USD",
          "total": String(body.total || '0.00')
        },
        "description": body.description || 'UBER HAIR product'
      }],
      "redirect_urls": {
        "return_url": process.env.SERVER_BASE_URL + "/paypal-success",
        "cancel_url": process.env.SERVER_BASE_URL + "/paypal-cancel"
      }
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        return reject(error);
      } else {
        return resolve(payment);
      }
    });
  });
}

module.exports = { createPayPalOrder };
