const iap = require('in-app-purchase');

iap.config({
  applePassword: process.env.APPLE_SHARED_SECRET || '',
  // google: service account config if used
});

iap.setup()
  .then(() => console.log('IAP setup done'))
  .catch(err => console.error('IAP setup error', err));

async function verifySubscription(platform, receipt) {
  try {
    let validated = null;
    if (platform === 'ios') {
      validated = await iap.validate(receipt, 'ios');
    } else {
      validated = await iap.validate(receipt, 'android');
    }
    const isValid = iap.isValidated(validated);
    return { success: isValid, data: validated };
  } catch (err) {
    console.error('Receipt verify error', err);
    return { success: false, error: err.message };
  }
}

module.exports = { verifySubscription };
