require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { verifySubscription } = require('./verifyReceipt');
const { createPayPalOrder } = require('./paypal');
const app = express();
app.use(bodyParser.json());

app.post('/verify-subscription', async (req, res) => {
  const { platform, receipt, userId } = req.body;
  try {
    const result = await verifySubscription(platform, receipt);
    if (result && result.success) {
      // TODO: update your DB: set membershipActive = true, expiryDate etc
      return res.json({ success: true, data: result.data });
    } else {
      return res.status(400).json({ success: false, error: result.error || 'Invalid receipt' });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Server error' });
  }
});

app.post('/create-paypal-order', async (req, res) => {
  try {
    const order = await createPayPalOrder(req.body);
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
