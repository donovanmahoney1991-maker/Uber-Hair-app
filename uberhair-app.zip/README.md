# UBER HAIR - GitHub-ready Package

This repository contains a starter React Native client and Node.js server for
**UBER HAIR**, including an in-app yearly membership ($4.99) flow designed for
iOS/Android using In-App Purchases and PayPal support for product sales.

## Structure
- client/  -> React Native app (minimal starter)
- server/  -> Node.js Express server (receipt verification placeholders + PayPal)
- docs/    -> Screenshots, wireframes (placeholder)

## Important: configuration
Copy `.env.example` to `.env` in the `server/` folder and fill in your credentials:
- PAYPAL_CLIENT_ID
- PAYPAL_CLIENT_SECRET
- APPLE_SHARED_SECRET (if using Apple subscriptions)
- SERVER_BASE_URL (should be https://base44.com/api per your config)

## How to run locally (development)
### Server
```bash
cd server
npm install
npm run start
```

### Client (React Native - Expo suggested for ease)
```bash
cd client
npm install
npx expo start
```

## Notes
- The in-app subscription IDs must be created in App Store Connect and Google Play Console.
- This repo includes placeholder receipt-verification logic (see server/verifyReceipt.js).
- Replace placeholder PayPal live credentials in `.env` before going live.
