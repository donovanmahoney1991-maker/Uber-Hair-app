# 💇‍♀️ UBER HAIR

**UBER HAIR** is a futuristic, mobile-first beauty app that connects clients and stylists — allowing users to **book services**, **switch between stylist and client roles**, and **shop beauty products** all in one place.

## ✨ Features

- 🔁 Switch between Stylist and Client mode instantly
- 💇‍♀️ Book hair, make-up, and body waxing appointments
- 💍 Schedule wedding or event services
- 🛍️ Stylists can sell hair, extensions, and beauty products
- 📸 Showcase stylist portfolios and client reviews
- 📊 Dashboard analytics for earnings and bookings
- 💳 $4.99/year membership subscription

## ⚙️ Setup Instructions

1. Clone the Repo
```bash
git clone https://github.com/YOURUSERNAME/uber-hair-app.git
cd uber-hair-app
```

2. Install Dependencies
```bash
npm install
# or
yarn install
```

3. Run the App
```bash
npm start
```

4. Build for iOS / Android
```bash
# iOS
npx expo build:ios

# Android
npx expo build:android
```

---

## 🧾 License

MIT © 2025 UBER HAIR  
All rights reserved.
